Assets folder placeholder. Add logos or icons here if desired.
